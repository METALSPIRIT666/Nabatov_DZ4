﻿using System;

//1. Дан целочисленный массив из 20 элементов.
//    Элементы массива могут принимать целые значения от –10 000 до 10 000 включительно.
//     Написать программу, позволяющую найти и вывести количество пар элементов массива, 
//      в которых хотя бы одно число делится на 3. 
//       В данной задаче под парой подразумевается два подряд идущих элемента массива.
//        Например, для массива из пяти элементов: 6; 2; 9; –3; 6 – ответ: 4.

namespace Nabatov_L4T1
{
    class Program
    {
        static void Main(string[] args)
        {
            var array = new int[20];
            var rand = new Random();
            for (int i = 0; i < array.Length; i++)
            {
                array[i] = rand.Next(-10000, 10000);
                Console.Write("{0} ", array[i]);
            }

            int count = 0;
            for (int i = 0; i < array.Length - 1; i++)
            {
                if (array[i] % 3 == 0 || array[i + 1] % 3 == 0)
                {
                    count++;
                }   
            }

            Console.Write("\n{0}", count);
            Console.ReadLine();
        }
    }
}
