﻿using System;


//2. а) Дописать класс для работы с одномерным массивом.
//       Реализовать конструктор, создающий массив заданной размерности 
//        и заполняющий массив числами от начального значения с заданным шагом.
//         Создать свойство Sum, которые возвращают сумму элементов массива, 
//          метод Inverse, меняющий знаки у всех элементов массива, 
//           Метод Multi, умножающий каждый элемент массива на определенное число, 
//            свойство MaxCount, возвращающее количество максимальных элементов.
//             В Main продемонстрировать работу класса.
//   б)* Добавить конструктор и методы, которые загружают данные из файла и записывают данные в файл.

namespace Nabatov_L4T2
{
    class Program
    {
        static void Main(string[] args)
        {
            //var array = new MyArray(1, 2, 7);
            var array = new MyArray("D:\\data.txt");
            array.Print();
            Console.WriteLine("Сумма элементов массива: {0}", array.Sum);
            array.Inverse();
            array.Print();
            array.Inverse();
            array.Print();
            array.Multi(2);
            array.Print();
            array[3] = 26;
            array[5] = 26;
            array.Print();
            Console.WriteLine("Количество максимальных элементов в массиве: {0}", array.MaxCount);
            array.PrintToFile("D:\\out.txt");
            Console.ReadLine();
        }
    }
}
