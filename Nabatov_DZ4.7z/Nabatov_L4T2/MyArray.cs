﻿using System;
using System.IO;

//2. а) Дописать класс для работы с одномерным массивом.
//       Реализовать конструктор, создающий массив заданной размерности 
//        и заполняющий массив числами от начального значения с заданным шагом.
//         Создать свойство Sum, которые возвращают сумму элементов массива, 
//          метод Inverse, меняющий знаки у всех элементов массива, 
//           Метод Multi, умножающий каждый элемент массива на определенное число, 
//            свойство MaxCount, возвращающее количество максимальных элементов.
//             В Main продемонстрировать работу класса.
//   б)* Добавить конструктор и методы, которые загружают данные из файла и записывают данные в файл.

namespace Nabatov_L4T2
{
    class MyArray
    {
        private int[] a;
        public int this[int i] {
            get
            {
                return a[i];
            }
            set
            {
                a[i] = value;
            }
        }

        public MyArray (int beg, int step, int length) 
        {
            a = new int[length];
            for (int i = 0; i < length; i++)
            {
                a[i] = beg;
                beg += step;
            }
        }

        public MyArray (string fileName)
        {
            if (File.Exists(fileName))
            {
                StreamReader sr = new StreamReader(fileName);
                a = new int[int.Parse(sr.ReadLine())];
                for (int i = 0; i < a.Length; i++)
                {
                    a[i] = int.Parse(sr.ReadLine());
                }
                sr.Close();

            }
            else
            {
                Console.WriteLine("Неправильно введено имя файла");
            }           
        }

        public int Sum
        {
            get
            {
                int result = 0;
                for (int i = 0; i < a.Length; i++)
                {
                    result += a[i];
                }
                return result;
            }
        }

        public void Inverse()
        {
            for (int i = 0; i < a.Length; i++)
            {
                a[i] = -a[i];
            }
        }

        public void Multi(int val)
        {
            for (int i = 0; i < a.Length; i++)
            {
                a[i] *= val;
            }
        }

        public int MaxCount
        {
            get
            {
                int result = 1;
                int max = a[0];
                for (int i = 1; i < a.Length; i++)
                {
                    if (a[i] > max)
                    {
                        max = a[i];
                        result = 1;
                    }
                    else if (a[i] == max)
                    {
                        result++;
                    }
                }
                return result;
            }
        }

        public override string ToString()
        {
            string result = string.Empty;
            for (int i = 0; i < a.Length; i++)
            {
                result += string.Format("{0} ", a[i]);
            }
            return result;
        }

        public void Print()
        {
            Console.WriteLine(ToString());
        }

        public void PrintToFile(string fileName)
        {
            StreamWriter sw = new StreamWriter(fileName);
            sw.Write(ToString());
            sw.Close();
            Console.WriteLine("Массив был записан в файл {0}", fileName);
        }

    }
}
