﻿using System;
using static StudHelper;
using System.IO;

/*4. Реализовать метод проверки логина и пароля.
      На вход подается логин и пароль. 
       На выходе истина, если прошел авторизацию, и ложь, если не прошел
        (Логин:root, Password:GeekBrains). Используя метод проверки логина и пароля, 
          написать программу: пользователь вводит логин и пароль, 
           программа пропускает его дальше или не пропускает. 
            С помощью цикла do while ограничить ввод пароля тремя попытками. */

namespace Nabatov_L2T4
{
    class Program
    {
        static void Main(string[] args)
        {
            string login = string.Empty;
            string password = string.Empty;
            string fileLine = string.Empty;
            string[] lineParam = new string[2];
            int triesLeft = 3;
            StreamReader sr = new StreamReader("D:\\data1.txt");
            while (triesLeft > 0 && !sr.EndOfStream)
            {
                fileLine = sr.ReadLine();
                lineParam = fileLine.Split(' ');
                login = lineParam[0];
                password = lineParam[1];
                Console.WriteLine("{0} {1}", login, password);
                if (!AuthIsPassed(login, password))
                {
                    triesLeft--;
                    Console.WriteLine("Осталось попыток: {0}", triesLeft);
                }
                else
                {
                    break;
                }
            }
            Pause();
        }

        static bool AuthIsPassed(string login, string pass)
        {
            const string LOGIN = "root";
            const string PASS = "GeekBrains";
            if (login == LOGIN && pass == PASS)
            {
                Console.WriteLine("Вы успешно прошли авторизацию!");
                return true;
            }
            else
            {
                Console.WriteLine("Неверный логин или пароль.");
                return false;
            }
        }

    }
}
