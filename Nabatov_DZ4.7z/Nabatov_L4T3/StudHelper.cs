﻿using System;

public class StudHelper
{
    static public void Pause()
    {
        Console.ReadLine();
    }

    static public string ConsoleReader(string msg)
    {
        Console.WriteLine(msg);
        return Console.ReadLine();
    }
}

